import UIKit

var i = 9
var j = 10
var sum = i+j
print(sum)

var k = 5.2
var v = 3.5
var product = 0.0;
product = k*v
print(product)

var s = 5.5
var w = 5.3
var sub = s-w;
print(sub)

